import json, sqlite3, time
from collections import defaultdict
from fastapi import FastAPI, Depends, Header, HTTPException, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from . import core

core.init()
app = FastAPI(title="BizMind AI API")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_methods=["*"], allow_headers=["*"])


class Cred(BaseModel):
    email: str = Field(pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$", max_length=200)
    password: str = Field(min_length=8, max_length=128)


class BizIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    greeting: str = Field(default="Hello! How can I help?", max_length=300)
    support_email: str = Field(default="", max_length=200)
    suggestions: list[str] = Field(default_factory=list, max_length=8)


class ChatIn(BaseModel):
    question: str = Field(min_length=1, max_length=500)
    lang: str = Field(default="English", max_length=30)
    history: list[dict] = Field(default_factory=list, max_length=12)  # previous turns: {"role","text"}


class FaqIn(BaseModel):
    question: str = Field(min_length=3, max_length=500)
    answer: str = Field(max_length=3000)


class FbIn(BaseModel):
    id: int
    helpful: bool


# ---------- auth helpers ----------
def user(authorization: str = Header("")):
    uid = core.read_token(authorization.removeprefix("Bearer ").strip())
    if not uid:
        raise HTTPException(401, "Not authenticated")
    return uid


def owned(biz_id: int, uid: int = Depends(user)):
    with core.db() as c:
        if not c.execute("SELECT 1 FROM businesses WHERE id=? AND owner_id=?", (biz_id, uid)).fetchone():
            raise HTTPException(404, "Business not found")  # 404 on purpose: don't reveal other tenants
    return biz_id


def _rate(bucket: dict, req: Request, per_min: int):
    ip, now = (req.client.host if req.client else "?"), time.time()
    bucket[ip] = [t for t in bucket[ip] if now - t < 60]
    if len(bucket[ip]) >= per_min:
        raise HTTPException(429, "Too many requests, slow down")
    bucket[ip].append(now)


chat_hits, auth_hits = defaultdict(list), defaultdict(list)
def chat_limit(req: Request): _rate(chat_hits, req, 20)
def auth_limit(req: Request): _rate(auth_hits, req, 15)


# ---------- auth ----------
@app.post("/api/auth/register", dependencies=[Depends(auth_limit)])
def register(b: Cred):
    try:
        with core.db() as c:
            uid = c.execute("INSERT INTO users(email,pw) VALUES(?,?)", (b.email.strip().lower(), core.hash_pw(b.password))).lastrowid
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Email already registered - please log in instead")
    return {"token": core.make_token(uid)}


@app.post("/api/auth/login", dependencies=[Depends(auth_limit)])
def login(b: Cred):
    with core.db() as c:
        r = c.execute("SELECT * FROM users WHERE email=?", (b.email.strip().lower(),)).fetchone()
    if not r or not core.check_pw(b.password, r["pw"]):
        raise HTTPException(401, "Invalid email or password")
    return {"token": core.make_token(r["id"])}


@app.get("/api/me")
def me(uid: int = Depends(user)):
    with core.db() as c:
        r = c.execute("SELECT id,email FROM users WHERE id=?", (uid,)).fetchone()
    if not r:
        raise HTTPException(401, "Not authenticated")
    return dict(r)


# ---------- businesses ----------
def _biz_row(r):
    d = dict(r)
    d["suggestions"] = json.loads(d.get("suggestions") or "[]")
    return d


@app.post("/api/businesses")
def create_biz(b: BizIn, uid: int = Depends(user)):
    sug = [s.strip() for s in b.suggestions if s.strip()]
    with core.db() as c:
        return {"id": c.execute("INSERT INTO businesses(owner_id,name,greeting,support_email,suggestions) VALUES(?,?,?,?,?)",
                                (uid, b.name.strip(), b.greeting, b.support_email.strip(), json.dumps(sug))).lastrowid}


@app.get("/api/businesses")
def list_biz(uid: int = Depends(user)):
    with core.db() as c:
        return [_biz_row(r) for r in c.execute("SELECT id,name,greeting,support_email,suggestions FROM businesses WHERE owner_id=? ORDER BY id", (uid,))]


@app.put("/api/b/{biz_id}")
def update_biz(b: BizIn, biz_id: int = Depends(owned)):
    sug = [s.strip() for s in b.suggestions if s.strip()]
    with core.db() as c:
        c.execute("UPDATE businesses SET name=?,greeting=?,support_email=?,suggestions=? WHERE id=?",
                  (b.name.strip(), b.greeting, b.support_email.strip(), json.dumps(sug), biz_id))
    return {"ok": True}


# ---------- documents (upload) ----------
@app.post("/api/b/{biz_id}/documents")
async def upload(file: UploadFile = File(...), biz_id: int = Depends(owned)):
    data = await file.read(core.MAX_BYTES + 1)
    try:
        return {"id": core.add_document(biz_id, file.filename or "upload", data), "status": "indexed"}
    except ValueError as e:
        raise HTTPException(422, str(e))


@app.get("/api/b/{biz_id}/documents")
def docs(biz_id: int = Depends(owned)):
    with core.db() as c:
        return [dict(r) for r in c.execute(
            "SELECT id,name,type,size,status,error,created,substr(text,1,1500) preview FROM documents WHERE biz_id=? ORDER BY id DESC", (biz_id,))]


@app.delete("/api/b/{biz_id}/documents/{doc_id}")
def del_doc(doc_id: int, biz_id: int = Depends(owned)):
    with core.db() as c:
        c.execute("DELETE FROM chunks WHERE doc_id=? AND biz_id=?", (doc_id, biz_id))
        c.execute("DELETE FROM documents WHERE id=? AND biz_id=?", (doc_id, biz_id))
    return {"ok": True}


# ---------- insights & improvements ----------
@app.get("/api/b/{biz_id}/stats")
def stats(biz_id: int = Depends(owned)):
    return core.stats(biz_id)


@app.get("/api/b/{biz_id}/gaps")
def gaps(biz_id: int = Depends(owned)):
    return core.gaps(biz_id)


@app.get("/api/b/{biz_id}/improvements")
def improvements(biz_id: int = Depends(owned)):
    return core.improvements(biz_id)


@app.post("/api/b/{biz_id}/review")
def review(biz_id: int = Depends(owned)):
    try:
        return {"review": core.ai_review(biz_id)}
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(502, f"AI service error: {e}")


@app.post("/api/b/{biz_id}/faqs")
def faq(f: FaqIn, biz_id: int = Depends(owned)):
    try:
        return {"doc_id": core.approve_faq(biz_id, f.question, f.answer)}
    except ValueError as e:
        raise HTTPException(422, str(e))


# ---------- public chatbot (no login: this is what customers use) ----------
@app.get("/api/public/businesses")
def public_businesses():
    """Minimal public directory for customers; never returns owner IDs or private settings."""
    with core.db() as c:
        rows = c.execute("SELECT id,name,greeting,suggestions FROM businesses WHERE is_demo=0 ORDER BY name COLLATE NOCASE").fetchall()
    return [_biz_row(r) for r in rows]


@app.get("/api/public/{biz_id}")
def info(biz_id: int):
    with core.db() as c:
        r = c.execute("SELECT id,name,greeting,suggestions,support_email,is_demo FROM businesses WHERE id=?", (biz_id,)).fetchone()
    if not r:
        raise HTTPException(404, "Not found")
    return _biz_row(r)


@app.post("/api/public/{biz_id}/chat", dependencies=[Depends(chat_limit)])
def chat(biz_id: int, b: ChatIn):
    info(biz_id)
    return core.answer(biz_id, b.question, b.lang, b.history)


@app.post("/api/public/{biz_id}/feedback")
def feedback(biz_id: int, f: FbIn):
    with core.db() as c:
        c.execute("UPDATE questions SET feedback=? WHERE id=? AND biz_id=?", (int(f.helpful), f.id, biz_id))
    return {"ok": True}


@app.post("/api/demo")
def demo():
    return {"id": core.seed_demo()}
