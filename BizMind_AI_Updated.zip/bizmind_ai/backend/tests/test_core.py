import os, sys, io, tempfile, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["DATABASE_PATH"] = os.path.join(tempfile.mkdtemp(), "t.db")
os.environ["ANTHROPIC_API_KEY"] = ""  # empty (not unset) so a real backend/.env key is never used in tests
from app import core
core.init()


def biz(name, email=""):
    with core.db() as c:
        return c.execute("INSERT INTO businesses(owner_id,name,support_email) VALUES(1,?,?)", (name, email)).lastrowid


class T(unittest.TestCase):
    def test_auth(self):
        h = core.hash_pw("secret123"); self.assertTrue(core.check_pw("secret123", h)); self.assertFalse(core.check_pw("x", h))
        self.assertFalse(core.check_pw("x", "garbage"))
        t = core.make_token(7); self.assertEqual(core.read_token(t), 7); self.assertIsNone(core.read_token(t[:-2] + "00"))
        self.assertIsNone(core.read_token(core.make_token(7, ttl=-5)))

    def test_upload_validation(self):
        b = biz("v")
        with self.assertRaises(ValueError): core.add_document(b, "a.exe", b"x")
        with self.assertRaises(ValueError): core.add_document(b, "bad.pdf", b"not a pdf")
        with core.db() as c: self.assertEqual(c.execute("SELECT COUNT(*) FROM documents WHERE biz_id=? AND status='failed'", (b,)).fetchone()[0], 2)

    def test_docx_with_table_and_real_pdf(self):
        import docx
        d = docx.Document(); d.add_paragraph("Our price list"); t = d.add_table(rows=1, cols=2)
        t.rows[0].cells[0].text = "Haircut"; t.rows[0].cells[1].text = "INR 300"
        buf = io.BytesIO(); d.save(buf)
        b = biz("docx"); core.add_document(b, "prices.docx", buf.getvalue())
        self.assertIn("Haircut | INR 300", core.retrieve(b, "haircut price")[0][0]["text"])
        from reportlab.pdfgen import canvas
        pb = io.BytesIO(); cv = canvas.Canvas(pb); cv.drawString(72, 750, "Delivery takes five working days."); cv.save()
        core.add_document(b, "ship.pdf", pb.getvalue())
        self.assertTrue(core.answer(b, "how long does delivery take?")["answered"])

    def test_long_pdf_style_text_is_split(self):
        text = " ".join(f"Sentence number {i} about topic{i}." for i in range(200))  # one giant paragraph, no blank lines
        ch = core.chunk(text); self.assertGreater(len(ch), 3); self.assertTrue(all(len(c) <= 800 for c in ch))

    def test_retrieval_and_isolation(self):
        a, b = biz("A"), biz("B")
        core.add_document(a, "a.txt", b"Refund policy: refunds within 7 days of enrollment.")
        core.add_document(b, "b.txt", b"Secret price list: platinum plan costs 999 dollars.")
        self.assertTrue(core.answer(a, "refund within 7 days?")["answered"])
        r = core.answer(a, "what does the platinum plan cost?")
        self.assertFalse(r["answered"]); self.assertEqual(r["sources"], [])
        self.assertEqual(core.retrieve(a, "platinum plan price")[0], [])

    def test_stemming_and_synonyms(self):
        b = biz("S"); core.add_document(b, "s.txt", b"Course fees: English costs INR 12,000 per term.\n\nOpening hours: 9 AM to 6 PM.")
        self.assertTrue(core.answer(b, "How much is the course?")["answered"])
        self.assertTrue(core.answer(b, "what are your timings?")["answered"])

    def test_gap_and_faq_flow(self):
        b = biz("G"); core.add_document(b, "d.txt", b"We open at 9 AM.")
        core.answer(b, "Do you offer scholarships?"); core.answer(b, "Are scholarships offered?")
        g = core.gaps(b); self.assertGreaterEqual(len(g), 1); self.assertEqual(core.stats(b)["unanswered"], 2)
        with self.assertRaises(ValueError): core.approve_faq(b, "Scholarships?", " ")
        core.approve_faq(b, "Do you offer scholarships?", "Yes, 10% for merit.")
        r = core.answer(b, "Do you offer scholarships?")
        self.assertTrue(r["answered"]); self.assertIn("10% for merit", r["answer"]); self.assertNotIn("Q:", r["answer"])

    def test_faq_entries_are_answered_individually(self):
        b = biz("Q"); core.add_document(b, "faq.txt", b"Q: What are your shipping charges?\nA: Shipping is free above INR 999, otherwise INR 49.\n\nQ: How long does delivery take?\nA: Delivery takes 3 to 5 working days.\n\nOur store sells tea.")
        self.assertEqual(len(core.chunk("Q: a?\nA: b\nQ: c?\nA: d")), 2)
        r = core.answer(b, "and how much is shipping?")
        self.assertEqual(r["answer"], "Shipping is free above INR 999, otherwise INR 49.")
        self.assertEqual(core.answer(b, "How long does delivery take?")["answer"], "Delivery takes 3 to 5 working days.")

    def test_chatbot_always_replies(self):
        b = biz("C"); core.add_document(b, "c.txt", b"Parking: free parking is available behind the building.")
        self.assertEqual(core.answer(b, "hi")["mode"], "smalltalk")
        self.assertEqual(core.answer(b, "Thanks!")["mode"], "smalltalk")
        r = core.answer(b, "What is the meaning of life?")  # nothing in docs, no AI key
        self.assertFalse(r["answered"]); self.assertTrue(r["answer"])
        empty = biz("E"); self.assertTrue(core.answer(empty, "price?")["answer"])  # business with no documents

    def test_followup_uses_history(self):
        b = biz("F"); core.add_document(b, "f.txt", b"Online classes: live online classes cost INR 5,000 per term.")
        r = core.answer(b, "and the price?", history=[{"role": "user", "text": "Do you have online classes?"}, {"role": "assistant", "text": "Yes."}])
        self.assertTrue(r["answered"])

    def test_improvements(self):
        b = biz("I")
        self.assertEqual(core.improvements(b)["items"][0]["severity"], "high")  # no documents yet
        core.add_document(b, "x.txt", b"We sell shoes. Welcome to our shop, we love shoes and happy customers all day long.")
        titles = " | ".join(i["title"] for i in core.improvements(b)["items"])
        self.assertIn("Pricing", titles); self.assertIn("support email", titles)
        with self.assertRaises(ValueError): core.ai_review(b)  # needs an API key
        d = core.seed_demo(); self.assertIn("Contact details", " ".join(i["title"] for i in core.improvements(d)["items"]))

    def test_demo(self):
        d = core.seed_demo(); self.assertEqual(d, core.seed_demo())
        self.assertTrue(core.answer(d, "What is the refund policy?")["answered"])
        self.assertGreater(core.stats(d)["simulated_rows"], 0)


class LLMPaths(unittest.TestCase):
    """AI-key code paths, with core.llm mocked (no network)."""
    def setUp(self):
        self.orig, os.environ["ANTHROPIC_API_KEY"] = core.llm, "test-key"
        self.calls = []
    def tearDown(self):
        core.llm = self.orig; os.environ["ANTHROPIC_API_KEY"] = ""
    def test_grounded_then_general_then_failure(self):
        b = biz("L"); core.add_document(b, "l.txt", b"Refund policy: full refund within 7 days.")
        def fake(system, messages, max_tokens=600):
            self.calls.append((system[:25], messages))
            if "<context" in messages[-1]["content"]:
                return "You can get a full refund within 7 days."
            return "Paris is the capital of France."
        core.llm = fake
        r = core.answer(b, "what is the refund policy?")
        self.assertEqual(r["mode"], "llm"); self.assertTrue(r["answered"]); self.assertTrue(r["sources"])
        r = core.answer(b, "capital of France?")  # not in docs -> general knowledge, labelled, logged as a gap
        self.assertEqual(r["mode"], "general"); self.assertFalse(r["answered"]); self.assertIn("Paris", r["answer"])
        self.assertTrue(any("France" in q for g in core.gaps(b) for q in g["examples"]))
        core.llm = lambda *a, **k: "NOT_FOUND"  # model says docs don't answer -> falls to general (also NOT_FOUND text is never shown)
        r = core.answer(b, "refund for orders?"); self.assertNotEqual(r["mode"], "llm")
        def boom(*a, **k): raise RuntimeError("401 invalid key")
        core.llm = boom  # API down/bad key: customers still get the document excerpt, no internal error text
        r = core.answer(b, "what is the refund policy?")
        self.assertEqual(r["mode"], "extractive"); self.assertNotIn("401", r["answer"])
    def test_history_alternates_roles(self):
        h = core._clean_history([{"role": "assistant", "text": "hi"}, {"role": "user", "text": "a"}, {"role": "user", "text": "b"}, {"role": "assistant", "text": "c"}, {"role": "user", "text": "d"}])
        m = core._msgs(h, "final")
        self.assertEqual(m[0]["role"], "user"); self.assertEqual(m[-1]["content"], "final")
        self.assertTrue(all(m[i]["role"] != m[i + 1]["role"] for i in range(len(m) - 1)))


if __name__ == "__main__":
    unittest.main()
