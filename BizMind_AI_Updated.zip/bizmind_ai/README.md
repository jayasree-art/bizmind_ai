# BizMind AI
Upload your business documents (PDF / DOCX / TXT / MD / CSV) and get a customer-support chatbot that answers from them,
cites its sources, and tells you what is missing.

## What you see when you run it
1. **Login page** (always first - register once, then log in)
2. **Role selection** (choose Business Owner or Customer)
3. **Business Owner portal** (after choosing owner)
4. **Customer directory** (choose a published business chatbot)
5. **Dashboard** (backend portal): **Overview** · **Knowledge** (upload documents) · **Improvements** (what to fix / add) · **Chatbot** (test + share link) · **Settings**
4. **Chatbot** everywhere in the portal: on the front page, on the Chatbot tab, and as a floating chat bubble on the other dashboard tabs.
   Customers can use the public link `http://localhost:5173/#/chat/<id>` without logging in, or choose Customer after login to browse the public business directory.

## Run on Windows (VS Code, two terminals)
**Terminal 1 - backend** (Python 3.10+)
```powershell
cd backend
python -m venv .venv
.venv\Scripts\Activate.ps1          # in cmd.exe use: .venv\Scripts\activate.bat
pip install -r requirements.txt
copy .env.example .env              # then open backend\.env and set ANTHROPIC_API_KEY (optional)
uvicorn app.main:app --reload --port 8000
```
If PowerShell blocks the activate script: `Set-ExecutionPolicy -Scope Process Bypass`, then activate again.

**Terminal 2 - frontend** (Node 18+)
```powershell
cd frontend
npm install
npm run dev
```
Open **http://localhost:5173**. API docs: http://localhost:8000/docs. The backend must be running, otherwise login shows
"Cannot reach the server".

**Tests:** `cd backend` then `python -m unittest discover -s tests -v`

## How the chatbot answers (so it replies to every question)
1. Greetings / thanks / "what can you do" -> instant built-in reply.
2. Question found in your documents -> answer + sources + confidence (AI-written if `ANTHROPIC_API_KEY` is set, otherwise the best matching sentences).
3. Not in your documents + AI key set -> a general answer, clearly labelled *"not from your documents"*; it will not guess your prices/policies.
4. Not in your documents + no AI key -> closest related passage if any, otherwise an honest "couldn't find this" with a **Contact human support** link.
Every question that step 2 couldn't answer appears under **Improvements -> Unanswered customer questions**. Type the real answer once and the
chatbot uses it from then on. Follow-up questions ("and the price?") use the previous messages.

**Without an AI key the bot cannot truly answer *everything*** - it only knows your documents. Add `ANTHROPIC_API_KEY` to `backend/.env` for that.

## Improvements shown after you upload
Missing topics (pricing, refunds, contact details, hours, payment, delivery), failed / near-empty / duplicate files, missing support email,
low answer rate, answers rated unhelpful, general-knowledge answers, plus a 0-100 knowledge-health score. With an AI key you can also click
"Get an AI review of my documents".

## Mistakes fixed in this version
- No login-first flow -> the login page is now always first; front page after login; expired/invalid tokens return you to login.
- README used `set KEY=value`, which does **not** set environment variables in PowerShell, and `.env` was never read -> `.env` is now loaded automatically.
- The landing page scrolled itself down to the chat on load (`scrollIntoView`) -> fixed.
- SQLite connections were never closed (file locks on Windows) -> every connection is closed.
- Any registration error was reported as "Email already registered" -> only real duplicates are.
- PDFs without blank lines became one giant chunk -> long text is split; each FAQ entry is its own chunk (answers no longer mix).
- AI/network errors were shown to customers -> they now silently fall back to document excerpts (details printed in the server console).
- Random secret key changed on every restart (everyone logged out) -> a key is generated once and stored in `backend/.secret_key`.
- Validation errors showed as "Request failed (422)" -> readable messages; client-side checks on the login form.
- DOCX tables (price lists) were ignored -> now indexed. Password-protected PDFs get a clear error.
- Single-word-form matching ("fees" vs "fee", "pricing" vs "price", "timings" vs "hours") -> light stemming + synonyms.
- Added: improvements engine, file drag-and-drop, multi-file upload results, settings page, suggested questions, floating chat widget,
  chat memory, login/chat rate limits, `/api/me`.

## Role separation added in this update
- After login, users see separate Business Owner and Customer choices.
- The Customer directory lists published non-demo business chatbots without exposing owner IDs or private analytics.
- Customers can open a chatbot from the directory or use its shareable public link.
- Owner routes remain protected by the existing token-based backend ownership checks.

## Honest limitations
- Retrieval is lexical (BM25), not embeddings. A Telugu question against English documents usually won't match the documents (the AI key helps for general answers). Telugu/Hindi output is untested.
- No OCR for scanned PDFs, no streaming, no password reset, SQLite only, token stored in localStorage, plain CSS (no Tailwind).
- Verified in a sandbox **without internet**: all backend logic (14 unit tests, AI paths with a mocked model) and the full browser flow
  (login -> front page -> upload -> improvements -> chatbot, 24 checks). The sandbox could not install FastAPI or the npm packages, so
  `main.py` was exercised through a small FastAPI stand-in and the UI was bundled with esbuild with stand-ins for `recharts`/`lucide-react`.
  The real `uvicorn` / `vite` run has **not** been executed by me - if something small breaks on first run, send me the error text.
- The real Anthropic API call has never been made from here (no key / no network); it follows the documented Messages API.
