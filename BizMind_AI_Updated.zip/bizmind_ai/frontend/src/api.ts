import { useEffect, useState } from "react";

export const TOKEN_KEY = "bizmind_token";

// App registers this so ANY 401 (expired/invalid token) sends the user back to the login page
let onUnauth: () => void = () => {};
export const setUnauthHandler = (fn: () => void) => { onUnauth = fn; };

function errorMessage(status: number, body: any): string {
  const d = body?.detail;
  if (typeof d === "string") return d;
  if (Array.isArray(d) && d.length) {
    return d.map((x: any) => (Array.isArray(x.loc) && x.loc.length ? `${x.loc[x.loc.length - 1]}: ${x.msg}` : x.msg)).join("; ");
  }
  if (status >= 500) return "Server error - is the backend running on port 8000?";
  return `Request failed (${status})`;
}

export async function api(path: string, opts: { method?: string; body?: any } = {}, tok?: string): Promise<any> {
  const headers: Record<string, string> = {};
  if (tok) headers.Authorization = "Bearer " + tok;
  let body: any = undefined;
  if (opts.body instanceof FormData) body = opts.body;
  else if (opts.body !== undefined) { headers["Content-Type"] = "application/json"; body = JSON.stringify(opts.body); }
  let r: Response;
  try { r = await fetch("/api" + path, { method: opts.method || "GET", headers, body }); }
  catch { throw new Error("Cannot reach the server - is the backend running on port 8000?"); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 401 && tok) onUnauth();
    throw new Error(errorMessage(r.status, j));
  }
  return j;
}

export const useHash = () => {
  const read = () => location.hash.slice(1) || "/";
  const [h, setH] = useState(read());
  useEffect(() => {
    const f = () => setH(read());
    addEventListener("hashchange", f);
    return () => removeEventListener("hashchange", f);
  }, []);
  return h;
};

export const go = (p: string) => { location.hash = p; };
