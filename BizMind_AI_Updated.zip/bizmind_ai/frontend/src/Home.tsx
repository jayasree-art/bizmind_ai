import { Chat } from "./Chat";
import { go } from "./api";

/** Front page: shown right after login. */
export function Home({ email, bizId, bizName, isDemo }: { email: string; bizId: number | null; bizName: string; isDemo: boolean }) {
  return (<>
    <h1>Your Business Knowledge.<br /><span className="hl">One Intelligent Assistant.</span></h1>
    <p className="mut" style={{ maxWidth: 640 }}>
      Welcome{email ? `, ${email}` : ""}! Upload your PDF, DOCX and TXT files and get a 24/7 support chatbot that answers customers from your
      documents, cites its sources, and tells you what information is missing.
    </p>
    <p>
      <button className="btn" onClick={() => go("/app")}>{bizName ? "Open dashboard & upload documents" : "Set up your assistant"}</button>
    </p>
    <div className="grid" style={{ margin: "24px 0" }}>
      {[["1. Upload knowledge", "PDF, DOCX, TXT, MD or CSV in the dashboard"],
        ["2. Get improvement tips", "BizMind tells you what is missing or unclear"],
        ["3. Help customers", "The chatbot answers every question - with sources when it uses your documents"]].map(([t, d]) =>
        <div className="card" key={t}><b>{t}</b><p className="mut">{d}</p></div>)}
    </div>
    <h3>{bizName ? `Try your chatbot: ${bizName}` : "Try the chatbot (fictional demo business)"}</h3>
    {bizId ? <Chat bizId={bizId} /> : <div className="card">Starting the demo… (is the backend running?)</div>}
    {isDemo && <p className="mut">This is a fictional demo. Create your business in the dashboard to build your own chatbot.</p>}
  </>);
}
