import { useState } from "react";
import { Brain } from "lucide-react";
import { api } from "./api";

/** First page of the app: login / register. */
export function Auth({ onTok }: { onTok: (t: string) => void }) {
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [reg, setReg] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setErr("");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.trim())) return setErr("Enter a valid email address.");
    if (pw.length < 8) return setErr("Password must be at least 8 characters.");
    setBusy(true);
    try {
      const r = await api(reg ? "/auth/register" : "/auth/login", { method: "POST", body: { email: email.trim(), password: pw } });
      onTok(r.token);
    } catch (x: any) { setErr(x.message); }
    setBusy(false);
  };

  return (
    <div className="auth">
      <div className="card" style={{ maxWidth: 400, width: "100%" }}>
        <div style={{ textAlign: "center", marginBottom: 10 }}>
          <Brain size={34} /> <h2 style={{ margin: "6px 0 0" }}>BizMind AI</h2>
          <p className="mut" style={{ margin: "4px 0 0" }}>{reg ? "Create your account" : "Log in to your workspace"}</p>
        </div>
        <label className="mut">Email</label>
        <input type="email" autoComplete="email" placeholder="you@company.com" value={email} onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} />
        <label className="mut">Password</label>
        <input type="password" autoComplete={reg ? "new-password" : "current-password"} placeholder="At least 8 characters" value={pw} onChange={(e) => setPw(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} />
        {err && <div className="err" role="alert" style={{ margin: "6px 0" }}>{err}</div>}
        <button className="btn" style={{ width: "100%", marginTop: 8 }} onClick={submit} disabled={busy}>{busy ? "Please wait…" : reg ? "Create account" : "Log in"}</button>
        <p className="mut" style={{ textAlign: "center", marginBottom: 0 }}>
          {reg ? "Already have an account? " : "New here? "}
          <a href="#" onClick={(e) => { e.preventDefault(); setReg(!reg); setErr(""); }}>{reg ? "Log in" : "Create an account"}</a>
        </p>
      </div>
    </div>
  );
}
