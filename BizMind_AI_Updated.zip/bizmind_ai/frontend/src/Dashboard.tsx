import { useCallback, useEffect, useRef, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Upload, Trash2, Copy, Lightbulb } from "lucide-react";
import { api } from "./api";
import { Chat, ChatWidget } from "./Chat";

type Result = { name: string; ok: boolean; msg: string };
const TABS = ["overview", "knowledge", "improvements", "chatbot", "settings"];
const SEV: Record<string, string> = { high: "Important", medium: "Suggested", low: "Nice to have" };

function Suggestions({ items }: { items: any[] }) {
  if (!items.length) return <p>✅ Nothing to improve right now - great job.</p>;
  return <>{items.map((it, i) => (
    <div className={"tip " + it.severity} key={i}>
      <span className={"badge " + it.severity}>{SEV[it.severity]}</span> <b>{it.title}</b>
      <div className="mut">{it.detail}</div>
    </div>))}</>;
}

export function Dashboard({ tok, list, refresh }: { tok: string; list: any[]; refresh: () => Promise<void> }) {
  const [bid, setBid] = useState<number | null>(list[0]?.id ?? null);
  const [tab, setTab] = useState("overview");
  const [st, setSt] = useState<any>(null);
  const [docs, setDocs] = useState<any[]>([]);
  const [gaps, setGaps] = useState<any[]>([]);
  const [imp, setImp] = useState<any>(null);
  const [msg, setMsg] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [uploading, setUploading] = useState(false);
  const [drag, setDrag] = useState(false);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [review, setReview] = useState("");
  const [reviewing, setReviewing] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const biz = list.find((b) => b.id === bid);

  // onboarding + settings form state
  const [nm, setNm] = useState(""); const [em, setEm] = useState(""); const [gr, setGr] = useState("Hello! How can I help?"); const [sg, setSg] = useState("");
  useEffect(() => { if (biz) { setNm(biz.name); setEm(biz.support_email || ""); setGr(biz.greeting || ""); setSg((biz.suggestions || []).join("\n")); } }, [bid, list]);
  useEffect(() => { if (bid == null && list[0]) setBid(list[0].id); }, [list]);

  const load = useCallback(async (id: number) => {
    try {
      const [s, d, g, i] = await Promise.all([
        api(`/b/${id}/stats`, {}, tok), api(`/b/${id}/documents`, {}, tok), api(`/b/${id}/gaps`, {}, tok), api(`/b/${id}/improvements`, {}, tok)]);
      setSt(s); setDocs(d); setGaps(g); setImp(i);
    } catch (e: any) { setMsg(e.message); }
  }, [tok]);
  useEffect(() => { if (bid) load(bid); }, [bid, tab, load]);

  const payload = () => ({ name: nm, greeting: gr, support_email: em, suggestions: sg.split("\n").map((s) => s.trim()).filter(Boolean) });
  const create = async () => {
    setMsg("");
    try { const r = await api("/businesses", { method: "POST", body: { ...payload(), name: nm.trim() } }, tok); await refresh(); setBid(r.id); }
    catch (e: any) { setMsg(e.message); }
  };
  const save = async () => {
    try { await api(`/b/${bid}`, { method: "PUT", body: payload() }, tok); await refresh(); await load(bid!); setMsg("Settings saved."); }
    catch (e: any) { setMsg(e.message); }
  };

  const upload = async (files: FileList | File[] | null) => {
    if (!files || !bid) return;
    setUploading(true); setMsg(""); const out: Result[] = [];
    for (const f of Array.from(files)) {
      const fd = new FormData(); fd.append("file", f);
      try { await api(`/b/${bid}/documents`, { method: "POST", body: fd }, tok); out.push({ name: f.name, ok: true, msg: "uploaded and indexed" }); }
      catch (e: any) { out.push({ name: f.name, ok: false, msg: e.message }); }
    }
    setResults(out); setUploading(false); await load(bid);
    if (fileInput.current) fileInput.current.value = "";
  };

  const del = async (d: any) => {
    if (!confirm(`Delete "${d.name}"? The chatbot will forget it.`)) return;
    try { await api(`/b/${bid}/documents/${d.id}`, { method: "DELETE" }, tok); await load(bid!); } catch (e: any) { setMsg(e.message); }
  };

  const approve = async (g: any) => {
    try {
      await api(`/b/${bid}/faqs`, { method: "POST", body: { question: g.suggested_faq, answer: answers[g.suggested_faq] || "" } }, tok);
      setMsg("FAQ approved and added to the chatbot's knowledge."); await load(bid!);
    } catch (e: any) { setMsg(e.message); }
  };

  const runReview = async () => {
    setReviewing(true); setReview("");
    try { setReview((await api(`/b/${bid}/review`, { method: "POST" }, tok)).review); } catch (e: any) { setReview("⚠ " + e.message); }
    setReviewing(false);
  };

  // ---------- onboarding: no business yet ----------
  if (!bid) return (
    <div className="card" style={{ maxWidth: 520, margin: "20px auto" }}>
      <h3>Welcome! Let's set up your business</h3>
      <label className="mut">Business name</label><input value={nm} onChange={(e) => setNm(e.target.value)} placeholder="e.g. Sunrise Dental Clinic" />
      <label className="mut">Support email (optional - customers use it when the bot can't answer)</label><input value={em} onChange={(e) => setEm(e.target.value)} placeholder="support@yourbusiness.com" />
      {msg && <div className="err">{msg}</div>}
      <button className="btn" onClick={create} disabled={nm.trim().length < 2}>Create my assistant</button>
    </div>);

  const link = `${location.origin}/#/chat/${bid}`;
  const todo = imp ? imp.items.filter((i: any) => i.severity !== "low").length : 0;

  return (<>
    <div className="nav" style={{ margin: "10px 0" }}>
      <div className="tabs">{TABS.map((t) => (
        <button key={t} className={"btn sm" + (tab === t ? "" : " alt")} onClick={() => { setTab(t); setMsg(""); }}>
          {t}{t === "improvements" && todo > 0 ? <span className="count">{todo}</span> : null}
        </button>))}</div>
      {list.length > 1 && <select style={{ width: "auto" }} value={bid} onChange={(e) => setBid(Number(e.target.value))}>{list.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select>}
    </div>
    {msg && <p className="note">{msg}</p>}

    {tab === "overview" && st && <>
      <div className="grid">{[["Questions", st.questions], ["Answered", st.answered], ["Unanswered", st.unanswered], ["Documents", st.documents], ["Answer rate", st.coverage_pct == null ? "n/a" : st.coverage_pct + "%"]]
        .map(([k, v]) => <div className="card" key={k as string}><span className="mut">{k}</span><div className="big">{v}</div></div>)}</div>
      {imp && <div className="card" style={{ marginTop: 14 }}><b>Knowledge health: {imp.score}/100</b> <span className="mut">· {todo} improvement(s) suggested</span>{" "}
        <button className="btn sm alt" onClick={() => setTab("improvements")}>See improvements</button></div>}
      <div className="card" style={{ marginTop: 14 }}><b>Most asked questions</b>
        {st.top.length ? <div style={{ height: 200 }}><ResponsiveContainer width="100%" height="100%"><BarChart data={st.top}><XAxis dataKey="question" hide /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey="n" name="times asked" fill="#7c3aed" /></BarChart></ResponsiveContainer></div>
          : <p className="mut">No questions yet. Open the <a href="#" onClick={(e) => { e.preventDefault(); setTab("chatbot"); }}>chatbot tab</a> and ask something.</p>}</div>
      <div className="card" style={{ marginTop: 14 }}><b>Recent questions</b>{st.recent.length === 0 && <p className="mut">Nothing yet.</p>}
        {st.recent.map((r: any, i: number) => <div key={i}>{r.answered ? "✅" : "❓"} {r.question} {r.simulated ? <span className="tag">simulated demo</span> : null}</div>)}</div>
    </>}

    {tab === "knowledge" && <div className="card">
      <h3 style={{ marginTop: 0 }}>Upload documents</h3>
      <div className={"drop" + (drag ? " over" : "")} onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
        onDrop={(e) => { e.preventDefault(); setDrag(false); upload(e.dataTransfer.files); }} onClick={() => fileInput.current?.click()}>
        <Upload size={26} /><div><b>{uploading ? "Uploading…" : "Drag & drop files here, or click to browse"}</b></div>
        <small className="mut">PDF, DOCX, TXT, MD, CSV · up to 5 MB each</small>
        <input ref={fileInput} type="file" multiple hidden accept=".pdf,.docx,.txt,.md,.csv" onChange={(e) => upload(e.target.files)} />
      </div>
      {results.length > 0 && <div style={{ margin: "12px 0" }}>{results.map((r, i) => <div key={i} className={r.ok ? "ok" : "err"}>{r.ok ? "✅" : "❌"} <b>{r.name}</b>: {r.msg}</div>)}</div>}
      {results.some((r) => r.ok) && imp && <div className="card inner" style={{ margin: "12px 0" }}>
        <b><Lightbulb size={16} /> Improvements for your knowledge base</b>
        <Suggestions items={imp.items.slice(0, 4)} />
        {imp.items.length > 4 && <button className="btn sm alt" onClick={() => setTab("improvements")}>See all {imp.items.length} suggestions</button>}
      </div>}
      <h3>Your documents ({docs.length})</h3>
      {!docs.length && <p className="mut">No documents yet - the chatbot knows nothing until you upload some.</p>}
      {docs.map((d) => <details key={d.id} className="doc"><summary>
        <span>{d.name} · {d.type} · {(d.size / 1024).toFixed(1)} KB · <b className={d.status === "indexed" ? "ok" : "err"}>{d.status}</b> · {new Date(d.created * 1000).toLocaleDateString()}</span>
        <Trash2 size={15} onClick={(e) => { e.preventDefault(); del(d); }} /></summary>
        {d.error ? <span className="err">{d.error}</span> : <pre>{d.preview}</pre>}</details>)}
    </div>}

    {tab === "improvements" && <div className="card">
      <h3 style={{ marginTop: 0 }}>Knowledge Improvement Center</h3>
      {imp && <><p>Knowledge health: <b>{imp.score}/100</b></p><Suggestions items={imp.items} />
        <p>{imp.ai_enabled ? <button className="btn sm" onClick={runReview} disabled={reviewing || !imp.documents}>{reviewing ? "Reviewing…" : "✨ Get an AI review of my documents"}</button>
          : <span className="mut">Tip: add ANTHROPIC_API_KEY in backend/.env to unlock an AI review of your documents and general-knowledge answers.</span>}</p>
        {review && <div className="card inner" style={{ whiteSpace: "pre-wrap" }}>{review}</div>}</>}
      <h3>Unanswered customer questions</h3>
      <p className="mut">Questions your documents couldn't answer. Write the real answer once and the chatbot will use it from then on. BizMind never invents your policies.</p>
      {!gaps.length && <p>No gaps detected yet. Ask the chatbot something your documents don't cover.</p>}
      {gaps.map((g) => <div className="card inner" key={g.suggested_faq} style={{ margin: "10px 0" }}>
        <b>{g.suggested_faq}</b> <span className="tag">asked {g.count}×</span>
        <textarea rows={2} placeholder="Your official answer…" value={answers[g.suggested_faq] || ""} onChange={(e) => setAnswers({ ...answers, [g.suggested_faq]: e.target.value })} />
        <button className="btn sm" onClick={() => approve(g)}>Approve & add to knowledge</button></div>)}
    </div>}

    {tab === "chatbot" && <div className="grid2">
      <div><h3 style={{ marginTop: 0 }}>Test your chatbot</h3><Chat bizId={bid} height={380} />
        <p className="mut">Ask anything customers might ask. It answers from your documents first; unknown questions show up under Improvements.</p></div>
      <div className="card"><h3 style={{ marginTop: 0 }}>Share with customers</h3>
        <p className="mut">Public chatbot link (no login needed):</p>
        <div className="row"><input readOnly value={link} /><button className="btn alt" onClick={() => navigator.clipboard?.writeText(link)} aria-label="Copy link"><Copy size={15} /></button></div>
        <p className="mut">Embed on a website:</p><code className="code">{`<iframe src="${link}" width="400" height="560"></iframe>`}</code>
        <p className="mut">Note: a localhost link only works on your computer. Deploy the app to share it publicly.</p></div>
    </div>}

    {tab === "settings" && <div className="card" style={{ maxWidth: 560 }}>
      <h3 style={{ marginTop: 0 }}>Chatbot settings</h3>
      <label className="mut">Business name</label><input value={nm} onChange={(e) => setNm(e.target.value)} />
      <label className="mut">Greeting message</label><input value={gr} onChange={(e) => setGr(e.target.value)} />
      <label className="mut">Support email (shown when the bot can't answer)</label><input value={em} onChange={(e) => setEm(e.target.value)} placeholder="support@yourbusiness.com" />
      <label className="mut">Suggested questions (one per line, max 8)</label><textarea rows={4} value={sg} onChange={(e) => setSg(e.target.value)} placeholder={"What are your prices?\nWhat is your refund policy?"} />
      <button className="btn" onClick={save} disabled={nm.trim().length < 2}>Save settings</button>
    </div>}
    {tab !== "chatbot" && <ChatWidget bizId={bid} title={`Customer view · ${biz?.name || ""}`} />}
  </>);
}
