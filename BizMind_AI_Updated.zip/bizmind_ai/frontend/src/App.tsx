import { useCallback, useEffect, useState } from "react";
import { Brain, Sun, Moon, BriefcaseBusiness, MessageCircle } from "lucide-react";
import { api, go, setUnauthHandler, TOKEN_KEY, useHash } from "./api";
import { Auth } from "./Auth";
import { Home } from "./Home";
import { Dashboard } from "./Dashboard";
import { Chat } from "./Chat";

/*
  Page flow:
    not logged in  ->  Login page (always first)
    after login    ->  Front page (#/home)  ->  Dashboard with document upload (#/app)
    #/chat/<id>    ->  public customer chatbot, no login needed (share / embed link)
*/
export default function App() {
  const route = useHash();
  const [tok, setTok] = useState(localStorage.getItem(TOKEN_KEY) || "");
  const [checking, setChecking] = useState(!!tok);
  const [email, setEmail] = useState("");
  const [list, setList] = useState<any[]>([]);
  const [demoId, setDemoId] = useState<number | null>(null);
  const [dark, setDark] = useState(true);
  const [publicBusinesses, setPublicBusinesses] = useState<any[]>([]);

  const logout = useCallback(() => { localStorage.removeItem(TOKEN_KEY); setTok(""); setList([]); setEmail(""); setChecking(false); location.hash = ""; }, []);
  useEffect(() => setUnauthHandler(logout), [logout]);
  useEffect(() => { document.documentElement.dataset.theme = dark ? "dark" : "light"; }, [dark]);

  const refresh = useCallback(async () => { if (tok) setList(await api("/businesses", {}, tok)); }, [tok]);

  // validate the saved token on startup (an expired token sends the user back to login)
  useEffect(() => {
    if (!tok) return;
    let alive = true;
    Promise.all([api("/me", {}, tok), api("/businesses", {}, tok), api("/demo", { method: "POST" })])
      .then(([me, l, d]) => { if (alive) { setEmail(me.email); setList(l); setDemoId(d.id); } })
      .catch(() => {}).finally(() => alive && setChecking(false));
    return () => { alive = false; };
  }, [tok]);

  const onLogin = (t: string) => { localStorage.setItem(TOKEN_KEY, t); setChecking(true); setTok(t); go("/role"); };

  useEffect(() => { if (tok && !checking && route === "/") go("/role"); }, [tok, checking, route]);
  useEffect(() => { if (route === "/customer") api("/public/businesses").then(setPublicBusinesses).catch(() => setPublicBusinesses([])); }, [route]);

  // public customer chatbot link: no login required
  if (route.startsWith("/chat/")) {
    const id = Number(route.split("/")[2]);
    return <div className="wrap">{id ? <Chat bizId={id} height={380} /> : <div className="card">Invalid chat link.</div>}</div>;
  }

  // ALWAYS login first
  if (!tok) return <div className="wrap"><Auth onTok={onLogin} /></div>;

  if (route === "/role") return <div className="wrap">
    <div className="nav topbar"><b className="brand"><Brain size={18} /> BizMind AI</b><button className="btn alt sm" onClick={logout}>Log out</button></div>
    <div className="auth"><div style={{maxWidth:760,width:"100%"}}><h1 style={{textAlign:"center"}}>Welcome to BizMind AI</h1><p className="mut" style={{textAlign:"center"}}>Choose how you want to use the platform.</p>
      <div className="grid" style={{marginTop:24}}>
        <button className="card role-card" onClick={() => go("/home")}><BriefcaseBusiness size={30}/><h2>Business Owner</h2><p className="mut">Upload documents, test your chatbot, and review customer questions and feedback.</p><b>Open owner portal →</b></button>
        <button className="card role-card" onClick={() => go("/customer")}><MessageCircle size={30}/><h2>Customer</h2><p className="mut">Choose a business and ask its AI assistant questions using the business's published information.</p><b>Find a chatbot →</b></button>
      </div></div></div></div>;

  if (route === "/customer") return <div className="wrap">
    <div className="nav topbar"><b className="brand" onClick={() => go("/role")}><Brain size={18}/> BizMind AI</b><button className="btn alt sm" onClick={() => go("/role")}>Change role</button></div>
    <h1>Find a business</h1><p className="mut">Choose a business to start a conversation with its public AI assistant.</p>
    {!publicBusinesses.length ? <div className="card">No public business chatbots are available yet. Ask a business owner to create a chatbot and share its link with you.</div> : <div className="grid">{publicBusinesses.map((b:any) => <div className="card" key={b.id}><h3>{b.name}</h3><p className="mut">{b.greeting || "Ask us a question."}</p><button className="btn" onClick={() => go(`/chat/${b.id}`)}>Chat with this business</button></div>)}</div>}
  </div>;

  const mine = list[0] || null;
  const botId: number | null = mine ? mine.id : demoId;
  const onDash = route === "/app";
  return (
    <div className="wrap">
      <div className="nav topbar">
        <b className="brand" onClick={() => go("/home")}><Brain size={18} /> BizMind AI</b>
        <span className="navbtns">
          <button className={"btn sm" + (!onDash ? "" : " alt")} onClick={() => go("/home")}>Home</button>
          <button className={"btn sm" + (onDash ? "" : " alt")} onClick={() => go("/app")}>Dashboard</button>
          <button className="btn alt sm" onClick={() => setDark(!dark)} aria-label="Toggle theme">{dark ? <Sun size={14} /> : <Moon size={14} />}</button>
          <button className="btn alt sm" onClick={logout}>Log out</button>
        </span>
      </div>
      {checking ? <div className="card">Loading your workspace…</div>
        : onDash ? <Dashboard tok={tok} list={list} refresh={refresh} />
        : <Home email={email} bizId={botId} bizName={mine ? mine.name : ""} isDemo={!mine} />}
    </div>);
}
