import { useEffect, useRef, useState } from "react";
import { Copy, ThumbsUp, ThumbsDown, Send, MessageCircle, X } from "lucide-react";
import { api } from "./api";

type Msg = {
  role: "u" | "b"; text: string; q?: string; id?: number | null; answered?: boolean; confidence?: number; mode?: string;
  sources?: { doc: string; excerpt: string }[]; fb?: boolean;
};

function label(m: Msg): string {
  switch (m.mode) {
    case "llm": return `AI answer from your documents · confidence ${Math.round((m.confidence || 0) * 100)}%`;
    case "extractive": return `From your documents · match ${Math.round((m.confidence || 0) * 100)}%`;
    case "general": return "General answer · not from your documents";
    case "related": return "Closest related info · not an exact answer";
    case "none": return "Not found in documents";
    default: return "";
  }
}

/** The customer-facing chatbot. Used on the front page, in the dashboard, in the floating widget and on the public link. */
export function Chat({ bizId, height = 340 }: { bizId: number; height?: number }) {
  const [info, setInfo] = useState<any>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [q, setQ] = useState("");
  const [lang, setLang] = useState("English");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setInfo(null); setMsgs([]); setErr("");
    api("/public/" + bizId).then(setInfo).catch((e) => setErr(e.message));
  }, [bizId]);

  // scroll only the message box (never the whole page)
  useEffect(() => { if (box.current && msgs.length) box.current.scrollTop = box.current.scrollHeight; }, [msgs, busy]);

  const ask = async (raw: string) => {
    const text = raw.trim().slice(0, 500);
    if (!text || busy) return;
    const history = msgs.slice(-6).map((m) => ({ role: m.role === "u" ? "user" : "assistant", text: m.text.slice(0, 1500) }));
    setErr(""); setMsgs((m) => [...m, { role: "u", text }]); setQ(""); setBusy(true);
    try {
      const r = await api(`/public/${bizId}/chat`, { method: "POST", body: { question: text, lang, history } });
      setMsgs((m) => [...m, { role: "b", text: r.answer, q: text, id: r.id, answered: r.answered, confidence: r.confidence, mode: r.mode, sources: r.sources }]);
    } catch (e: any) { setErr(e.message); }
    setBusy(false);
  };

  const fb = (i: number, helpful: boolean) => {
    const id = msgs[i].id;
    if (id) api(`/public/${bizId}/feedback`, { method: "POST", body: { id, helpful } }).catch(() => {});
    setMsgs((m) => m.map((x, j) => (j === i ? { ...x, fb: helpful } : x)));
  };

  if (!info) return <div className="card">{err ? <span className="err">{err}</span> : "Loading chatbot…"}</div>;
  return (
    <div className="card chat">
      <div className="nav">
        <b>{info.name}</b>
        <select style={{ width: "auto" }} value={lang} onChange={(e) => setLang(e.target.value)} aria-label="Answer language">
          <option>English</option><option>Telugu</option><option>Hindi</option>
        </select>
      </div>
      <div className="msgs" ref={box} style={{ height }}>
        <div className="msg b">{info.greeting}</div>
        {!msgs.length && info.suggestions.map((s: string) => <span key={s} className="chip" onClick={() => ask(s)}>{s}</span>)}
        {msgs.map((m, i) => (
          <div key={i} className={"msg " + m.role}>
            {m.text}
            {m.role === "b" && m.mode !== "smalltalk" && (
              <div className="meta">
                <small className="mut">{label(m)}</small>
                <div className="acts">
                  <Copy size={14} onClick={() => navigator.clipboard?.writeText(m.text)} />
                  {m.id && <>
                    <ThumbsUp size={14} style={{ opacity: m.fb === true ? 1 : .45 }} onClick={() => fb(i, true)} />
                    <ThumbsDown size={14} style={{ opacity: m.fb === false ? 1 : .45 }} onClick={() => fb(i, false)} />
                  </>}
                </div>
                {!!m.sources?.length && <details><summary>Sources ({m.sources.length})</summary>{m.sources.map((s, k) => <p key={k}><b>{s.doc}</b>: <i>{s.excerpt}</i></p>)}</details>}
                {!m.answered && info.support_email && <div><a href={`mailto:${info.support_email}?subject=${encodeURIComponent("Question: " + (m.q || ""))}`}>Contact human support</a></div>}
              </div>
            )}
          </div>
        ))}
        {busy && <div className="msg b mut">Typing…</div>}
      </div>
      {err && <div className="err">{err}</div>}
      <div className="row">
        <input value={q} placeholder="Ask a question…" maxLength={500} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && ask(q)} />
        <button className="btn" onClick={() => ask(q)} disabled={busy} aria-label="Send"><Send size={16} /></button>
        <button className="btn alt" onClick={() => setMsgs([])}>Clear</button>
      </div>
    </div>
  );
}

/** Floating chat bubble shown inside the portal. */
export function ChatWidget({ bizId, title }: { bizId: number; title: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="widget">
      {open && <div className="widget-panel"><div className="nav mut"><small>{title}</small></div><Chat bizId={bizId} height={300} /></div>}
      <button className="fab" onClick={() => setOpen(!open)} aria-label={open ? "Close chat" : "Open chat"}>{open ? <X size={22} /> : <MessageCircle size={22} />}</button>
    </div>
  );
}
