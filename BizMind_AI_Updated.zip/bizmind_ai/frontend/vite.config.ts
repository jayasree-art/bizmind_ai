import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// the browser talks to /api on the Vite dev server, which forwards to the FastAPI backend
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, proxy: { "/api": { target: "http://127.0.0.1:8000", changeOrigin: true } } },
});
